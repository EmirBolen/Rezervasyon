document.getElementById('reservationForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('reservationMessage').textContent = 'Rezervasyonunuz alınmıştır. Sizi ağırlamaktan mutluluk duyarız!';
  this.reset();
});

document.getElementById('contactForm')?.addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('contactMessage').textContent = 'Mesajınız başarıyla gönderildi. En kısa sürede sizinle iletişime geçeceğiz!';
  this.reset();
});

// Mobil menü açılır kapanır
const menuButton = document.querySelector('.menu-button');
const navLinks = document.querySelector('.nav-links');

menuButton.addEventListener('click', () => {
  navLinks.classList.toggle('active');
});

// İçerik bölümleri için kaydırma animasyonu
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('show');
    } else {
      entry.target.classList.remove('show');
    }
  });
});

document.querySelectorAll('.section').forEach((section) => {
  observer.observe(section);
});

// Form doğrulama
const form = document.querySelector('#contactForm');
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = form.querySelector('input[name="email"]').value;
  const message = form.querySelector('#contactMessage');
  if (!email.includes('@')) {
    message.textContent = 'Lütfen geçerli bir e-posta adresi girin.';
    message.style.color = 'red';
  } else {
    message.textContent = 'Mesajınız gönderildi!';
    message.style.color = 'green';
    form.reset();
  }
});

// Dinamik içerik yükleme (örnek)
async function loadMenu() {
  const response = await fetch('https://api.example.com/menu');
  const data = await response.json();
  const menuContainer = document.querySelector('.menu-items');
  data.forEach(item => {
    const menuItem = document.createElement('div');
    menuItem.classList.add('menu-item');
    menuItem.innerHTML = `<img src="${item.image}" alt="${item.name}"><h3>${item.name}</h3><p>${item.description}</p>`;
    menuContainer.appendChild(menuItem);
  });
}

// loadMenu(); // Uncomment to load menu from API

// Animasyonlar ve geçişler için örnek
const buttons = document.querySelectorAll('.btn-primary');
buttons.forEach(button => {
  button.addEventListener('mouseover', () => {
    button.style.transform = 'scale(1.1)';
  });
  button.addEventListener('mouseout', () => {
    button.style.transform = 'scale(1)';
  });
});

// Öne Çıkanlar ve Özel Etkinlikler bölümleri için animasyonlar
const highlightSections = document.querySelectorAll('.highlights-section, .events-section');

highlightSections.forEach(section => {
  section.addEventListener('mouseenter', () => {
    section.style.transform = 'scale(1.02)';
    section.style.transition = 'transform 0.3s ease-in-out';
  });
  section.addEventListener('mouseleave', () => {
    section.style.transform = 'scale(1)';
  });
}); 