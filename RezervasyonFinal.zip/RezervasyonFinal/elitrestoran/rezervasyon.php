<?php
// Hata gösterimini aç
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Veritabanı bağlantısı
$baglanti = new mysqli("localhost", "root", "", "rezervasyon_db");
$baglanti->set_charset("utf8");

if ($baglanti->connect_error) {
    echo "error";
    exit;
}

// POST verilerini al
$ad     = trim($_POST['name'] ?? '');
$telefon = trim($_POST['phone'] ?? '');
$tarih  = $_POST['date'] ?? '';
$saat   = $_POST['time'] ?? '';
$kisi   = intval($_POST['guests'] ?? 0);
$masa   = $_POST['masa_no'] ?? '';
$sube   = $_POST['sube'] ?? '';
$not    = trim($_POST['note'] ?? '');

// Zorunlu alan kontrolü
if (empty($ad) || empty($telefon) || empty($tarih) || empty($saat) || empty($kisi) || empty($masa) || empty($sube)) {
    echo "error";
    exit;
}

// Aynı tarih, saat, masa ve şube için doluluk kontrolü
$kontrolSorgu = "SELECT COUNT(*) FROM rezervasyonlar WHERE tarih = ? AND saat = ? AND masa_no = ? AND sube = ?";
$kontrol = $baglanti->prepare($kontrolSorgu);
$kontrol->bind_param("ssss", $tarih, $saat, $masa, $sube);
$kontrol->execute();
$kontrol->bind_result($adet);
$kontrol->fetch();
$kontrol->close();

if ($adet > 0) {
    echo "duplicate";
    exit;
}

// Kayıt ekleme
$sql = "INSERT INTO rezervasyonlar 
(adsoyad, telefon, tarih, saat, kisi_sayisi, masa_no, sube, notlar, kaynak) 
VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'web')";

$stmt = $baglanti->prepare($sql);
if (!$stmt) {
    echo "error";
    exit;
}

$stmt->bind_param("ssssisss", $ad, $telefon, $tarih, $saat, $kisi, $masa, $sube, $not);

if ($stmt->execute()) {
    echo "success";
} else {
    echo "error";
}

$stmt->close();
$baglanti->close();
?>
