﻿using MySql.Data.MySqlClient;
using System.Data;

namespace RezervasyonUygulama
{
    public class Database
    {
        private string connectionString = "Server=localhost;Database=rezervasyon_db;Uid=root;Pwd=;";

        public DataTable Query(string query)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public void Execute(string query)
        {
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
