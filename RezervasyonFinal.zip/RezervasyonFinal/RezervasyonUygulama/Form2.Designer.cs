﻿namespace RezervasyonUygulama
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.Label lblSube;
        private System.Windows.Forms.DateTimePicker dtTarih;
        private System.Windows.Forms.ComboBox cmbSube;
        private System.Windows.Forms.Button btnFiltrele;
        private System.Windows.Forms.Button btnSil;
        private System.Windows.Forms.DataGridView dataGridView1;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTarih = new System.Windows.Forms.Label();
            this.lblSube = new System.Windows.Forms.Label();
            this.dtTarih = new System.Windows.Forms.DateTimePicker();
            this.cmbSube = new System.Windows.Forms.ComboBox();
            this.btnFiltrele = new System.Windows.Forms.Button();
            this.btnSil = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();

            // Label: Tarih
            this.lblTarih.Text = "Tarih:";
            this.lblTarih.Location = new System.Drawing.Point(30, 30);
            this.lblTarih.Size = new System.Drawing.Size(100, 20);

            // DateTimePicker: dtTarih
            this.dtTarih.Location = new System.Drawing.Point(130, 30);
            this.dtTarih.Size = new System.Drawing.Size(200, 22);
            this.dtTarih.ValueChanged += new System.EventHandler(this.Form2_Load);

            // Label: Şube
            this.lblSube.Text = "Şube:";
            this.lblSube.Location = new System.Drawing.Point(30, 70);
            this.lblSube.Size = new System.Drawing.Size(100, 20);

            // ComboBox: cmbSube
            this.cmbSube.Location = new System.Drawing.Point(130, 70);
            this.cmbSube.Size = new System.Drawing.Size(200, 22);
            this.cmbSube.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            // Button: Filtrele
            this.btnFiltrele.Text = "Filtrele";
            this.btnFiltrele.Location = new System.Drawing.Point(350, 30);
            this.btnFiltrele.Size = new System.Drawing.Size(100, 60);
            this.btnFiltrele.BackColor = System.Drawing.Color.FromArgb(255, 193, 7);
            this.btnFiltrele.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFiltrele.Click += new System.EventHandler(this.btnFiltrele_Click);

            // Button: Sil
            this.btnSil.Text = "Seçili Kaydı Sil";
            this.btnSil.Location = new System.Drawing.Point(470, 30);
            this.btnSil.Size = new System.Drawing.Size(140, 60);
            this.btnSil.BackColor = System.Drawing.Color.FromArgb(211, 47, 47);
            this.btnSil.ForeColor = System.Drawing.Color.White;
            this.btnSil.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);

            // DataGridView: dataGridView1
            this.dataGridView1.Location = new System.Drawing.Point(30, 110);
            this.dataGridView1.Size = new System.Drawing.Size(740, 380);
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ReadOnly = true;

            // Form2
            this.ClientSize = new System.Drawing.Size(800, 520);
            this.Controls.Add(this.lblTarih);
            this.Controls.Add(this.dtTarih);
            this.Controls.Add(this.lblSube);
            this.Controls.Add(this.cmbSube);
            this.Controls.Add(this.btnFiltrele);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form2";
            this.Text = "Kayıtları Listele ve Sil";
            this.Load += new System.EventHandler(this.Form2_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
