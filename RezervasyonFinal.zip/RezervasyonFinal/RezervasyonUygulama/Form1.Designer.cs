﻿using System.Drawing;
using System.Windows.Forms;

namespace RezervasyonUygulama
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblAdSoyad;
        private System.Windows.Forms.Label lblTelefon;
        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.Label lblSaat;
        private System.Windows.Forms.Label lblMasa;
        private System.Windows.Forms.Label lblKisi;
        private System.Windows.Forms.Label lblSube;

        private System.Windows.Forms.TextBox txtAdSoyad;
        private System.Windows.Forms.MaskedTextBox txtTelefon;
        private System.Windows.Forms.DateTimePicker dtTarih;
        private System.Windows.Forms.ComboBox cmbSaat;
        private System.Windows.Forms.ComboBox cmbMasa;
        private System.Windows.Forms.NumericUpDown nudKisi;
        private System.Windows.Forms.ComboBox cmbSube;
        private System.Windows.Forms.Button btnKaydet;
        private System.Windows.Forms.Button btnListele;
        private System.Windows.Forms.FlowLayoutPanel flpMasalar;
        private System.Windows.Forms.PictureBox pictureBoxLogo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblAdSoyad = new System.Windows.Forms.Label();
            this.lblTelefon = new System.Windows.Forms.Label();
            this.lblTarih = new System.Windows.Forms.Label();
            this.lblSaat = new System.Windows.Forms.Label();
            this.lblMasa = new System.Windows.Forms.Label();
            this.lblKisi = new System.Windows.Forms.Label();
            this.lblSube = new System.Windows.Forms.Label();

            this.txtAdSoyad = new System.Windows.Forms.TextBox();
            this.txtTelefon = new System.Windows.Forms.MaskedTextBox();
            this.dtTarih = new System.Windows.Forms.DateTimePicker();
            this.cmbSaat = new System.Windows.Forms.ComboBox();
            this.cmbMasa = new System.Windows.Forms.ComboBox();
            this.nudKisi = new System.Windows.Forms.NumericUpDown();
            this.cmbSube = new System.Windows.Forms.ComboBox();
            this.btnKaydet = new System.Windows.Forms.Button();
            this.btnListele = new System.Windows.Forms.Button();
            this.flpMasalar = new System.Windows.Forms.FlowLayoutPanel();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();

            ((System.ComponentModel.ISupportInitialize)(this.nudKisi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.SuspendLayout();

            int x = 30, y = 30, w = 240, h = 25, spacing = 40;

            // Label ve kontroller
            void AddLabelAndControl(string labelText, System.Windows.Forms.Control label, System.Windows.Forms.Control control)
            {
                label.Text = labelText;
                label.Location = new System.Drawing.Point(x, y);
                label.Size = new System.Drawing.Size(w, 20);

                y += 20;

                control.Location = new System.Drawing.Point(x, y);
                control.Size = new System.Drawing.Size(w, h);

                this.Controls.Add(label);
                this.Controls.Add(control);

                y += spacing;
            }

            AddLabelAndControl("Ad Soyad:", lblAdSoyad, txtAdSoyad);
            AddLabelAndControl("Telefon (örn: +90 5XX XXX XXXX):", lblTelefon, txtTelefon);
            txtTelefon.Mask = "(+90) 000-000-0000";

            AddLabelAndControl("Tarih:", lblTarih, dtTarih);
            dtTarih.ValueChanged += new System.EventHandler(this.dtTarih_ValueChanged);

            AddLabelAndControl("Saat:", lblSaat, cmbSaat);
            cmbSaat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cmbSaat.SelectedIndexChanged += new System.EventHandler(this.cmbSaat_SelectedIndexChanged);

            AddLabelAndControl("Masa:", lblMasa, cmbMasa);
            cmbMasa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            AddLabelAndControl("Kişi Sayısı:", lblKisi, nudKisi);
            nudKisi.Minimum = 1;
            nudKisi.Maximum = 20;

            AddLabelAndControl("Şube:", lblSube, cmbSube);
            cmbSube.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            cmbSube.SelectedIndexChanged += new System.EventHandler(this.cmbSube_SelectedIndexChanged);

            // Kaydet Butonu
            btnKaydet.Text = "Rezervasyon Kaydet";
            btnKaydet.Location = new System.Drawing.Point(x, y);
            btnKaydet.Size = new System.Drawing.Size(w, 35);
            btnKaydet.BackColor = System.Drawing.Color.FromArgb(183, 28, 28);
            btnKaydet.ForeColor = System.Drawing.Color.White;
            btnKaydet.FlatStyle = FlatStyle.Flat;
            btnKaydet.Click += new System.EventHandler(this.btnKaydet_Click);
            this.Controls.Add(btnKaydet);

            y += 45;

            // Listele Butonu
            btnListele.Text = "Kayıtları Listele";
            btnListele.Location = new System.Drawing.Point(x, y);
            btnListele.Size = new System.Drawing.Size(w, 35);
            btnListele.BackColor = System.Drawing.Color.FromArgb(30, 136, 229);
            btnListele.ForeColor = Color.White;
            btnListele.FlatStyle = FlatStyle.Flat;
            btnListele.Click += new System.EventHandler(this.btnListele_Click);
            this.Controls.Add(btnListele);

            // Logo PictureBox
            pictureBoxLogo.Location = new System.Drawing.Point(x, y + 50);
            pictureBoxLogo.Size = new System.Drawing.Size(100, 100);
            pictureBoxLogo.SizeMode = PictureBoxSizeMode.StretchImage;
            try
            {
                pictureBoxLogo.Image = System.Drawing.Image.FromFile("logo.jpeg");
            }
            catch { }
            this.Controls.Add(pictureBoxLogo);

            // Masa paneli
            flpMasalar.Location = new System.Drawing.Point(320, 30);
            flpMasalar.Size = new System.Drawing.Size(450, 450);
            flpMasalar.AutoScroll = true;
            flpMasalar.BorderStyle = BorderStyle.FixedSingle;
            this.Controls.Add(flpMasalar);

            // Form Ayarları
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Name = "Form1";
            this.Text = "Rezervasyon Oluştur";
            this.Load += new System.EventHandler(this.Form1_Load);

            ((System.ComponentModel.ISupportInitialize)(this.nudKisi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.ResumeLayout(false);
        }
    }
}
