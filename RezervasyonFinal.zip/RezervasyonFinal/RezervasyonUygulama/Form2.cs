﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace RezervasyonUygulama
{
    public partial class Form2 : Form
    {
        private string connectionString = "Server=localhost;Database=rezervasyon_db;Uid=root;Pwd=;";

        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            cmbSube.Items.AddRange(new object[] { "Tümü", "Kadıköy", "Üsküdar", "Beşiktaş" });
            cmbSube.SelectedIndex = 0;
            dtTarih.Value = DateTime.Today;

            KayitlariYukle();
            dataGridView1.CellDoubleClick += dataGridView1_CellDoubleClick;
        }

        private void KayitlariYukle()
        {
            string sube = cmbSube.SelectedItem.ToString();
            string tarih = dtTarih.Value.ToString("yyyy-MM-dd");

            string query = "SELECT * FROM rezervasyonlar";

            if (sube != "Tümü")
            {
                query += $" WHERE sube = '{sube}' AND tarih = '{tarih}'";
            }

            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                conn.Open();
                MySqlDataAdapter da = new MySqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Lütfen silmek için bir kayıt seçin.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var seciliSatir = dataGridView1.SelectedRows[0];
            int id = Convert.ToInt32(seciliSatir.Cells["id"].Value);

            DialogResult sonuc = MessageBox.Show("Bu kaydı silmek istediğinize emin misiniz?", "Silme Onayı", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sonuc == DialogResult.Yes)
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = $"DELETE FROM rezervasyonlar WHERE id = {id}";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Kayıt silindi.");
                KayitlariYukle();
            }
        }

        private void btnFiltrele_Click(object sender, EventArgs e)
        {
            KayitlariYukle();
        }

        // ✅ Düzenleme işlemi: Satıra çift tıklanınca Form1'e gönder
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dataGridView1.Columns.Contains("id"))
            {
                var row = dataGridView1.Rows[e.RowIndex];

                string satir = $"{row.Cells["adsoyad"].Value} | {row.Cells["telefon"].Value} | {Convert.ToDateTime(row.Cells["tarih"].Value).ToShortDateString()} | " +
                               $"Saat: {row.Cells["saat"].Value} | Masa: {row.Cells["masa"].Value} | Kişi: {row.Cells["kisi"].Value} | Şube: {row.Cells["sube"].Value}";

                Form1 frm = new Form1();
                frm.SetDuzenlemeSatiri(satir);
                frm.ShowDialog();
                KayitlariYukle(); // tekrar yükle
            }
        }
    }
}
